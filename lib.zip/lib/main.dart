import 'package:flutter/material.dart';
import 'package:calculator/screens/Home.dart';

void main() {
  runApp(const MaterialApp(
    title: "navigation basic",
    home: Home(),
  ));
}

