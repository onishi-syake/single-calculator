import 'package:flutter/material.dart';

class Result extends StatelessWidget {

  Result(this._result);
  int _result;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Screen B"),
      ),
      body: Container(
        color: Colors.teal,
        child: Align(
          alignment: Alignment(0, -0.2),
          child: Text(
            "$_result",
            style: TextStyle(
              fontSize: 100.0,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}
