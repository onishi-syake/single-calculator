import 'package:flutter/material.dart';

import 'Result.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _firstNum = 0;
  int _category = 0;
  int _secondNum = 0;
  int _result = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("calculator"),
      ),
      body: Column(
        children: [
          SizedBox(height: 80,),
          Row(
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                onPressed: () {
                  setState(() {
                    if (_category > 0) {
                      _secondNum *= 10;
                      _secondNum += 1;
                    }else {
                      _firstNum *= 10;
                      _firstNum += 1;
                    }
                  });
                },
                child: Text("1"),
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                  onPressed: () {
                    setState(() {
                      if (_category > 0) {
                        _secondNum *= 10;
                        _secondNum += 2;
                      }else {
                        _firstNum *= 10;
                        _firstNum += 2;
                      }
                    });
                  },
                  child: Text("2")
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                  onPressed: () {
                    setState(() {
                      if (_category > 0) {
                        _secondNum *= 10;
                        _secondNum += 3;
                      }else {
                        _firstNum *= 10;
                        _firstNum += 3;
                      }
                    });
                  },
                  child: Text("3")
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                  onPressed: () {
                    setState(() {
                      _category = 1;
                    });
                  },
                  child: Text("+")
              )
            ],
          ),
          Row(
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                onPressed: () {
                  setState(() {
                    if (_category > 0) {
                      _secondNum *= 10;
                      _secondNum += 4;
                    }else {
                      _firstNum *= 10;
                      _firstNum += 4;
                    }
                  });
                },
                child: Text("4"),
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                  onPressed: () {
                    setState(() {
                      if (_category > 0) {
                        _secondNum *= 10;
                        _secondNum += 5;
                      }else {
                        _firstNum *= 10;
                        _firstNum += 5;
                      }
                    });
                  },
                  child: Text("5")
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                  onPressed: () {
                    setState(() {
                      if (_category > 0) {
                        _secondNum *= 10;
                        _secondNum += 6;
                      }else {
                        _firstNum *= 10;
                        _firstNum += 6;
                      }
                    });
                  },
                  child: Text("6")
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                  onPressed: () {
                    setState(() {
                      _category = 2;
                    });
                  },
                  child: Text("-")
              )
            ],
          ),
          Row(
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                onPressed: () {
                  setState(() {
                    if (_category > 0) {
                      _secondNum *= 10;
                      _secondNum += 7;
                    }else {
                      _firstNum *= 10;
                      _firstNum += 7;
                    }
                  });
                },
                child: Text("7"),
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                  onPressed: () {
                    setState(() {
                      if (_category > 0) {
                        _secondNum *= 10;
                        _secondNum += 8;
                      }else {
                        _firstNum *= 10;
                        _firstNum += 8;
                      }
                    });
                  },
                  child: Text("8")
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                  onPressed: () {
                    setState(() {
                      if (_category > 0) {
                        _secondNum *= 10;
                        _secondNum += 9;
                      }else {
                        _firstNum *= 10;
                        _firstNum += 9;
                      }
                    });
                  },
                  child: Text("9")
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                  onPressed: () {
                    setState(() {
                      _category = 3;
                    });
                  },
                  child: Text("*")
              )
            ],
          ),
          Row(
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                onPressed: () {
                  setState(() {
                    if (_category > 0) {
                      _secondNum *= 10;
                      _secondNum += 0;
                    }else {
                      _firstNum *= 10;
                      _firstNum += 0;
                    }
                  });
                },
                child: Text("0"),
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize: Size(160, 80)),
                  onPressed: () {
                    if(_category == 1){
                      _result = _firstNum + _secondNum;
                    }
                    if(_category == 2){
                      _result = _firstNum - _secondNum;
                    }
                    if(_category == 3){
                      _result = _firstNum * _secondNum;
                    }
                    if(_category == 4){
                      _result = _firstNum ~/ _secondNum;
                    }
                    Navigator.push(context, MaterialPageRoute(builder: (context){
                      return Result(_result);
                    }));
                  },
                  child: Text("=")
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize: Size(80, 80)),
                  onPressed: () {
                    setState(() {
                      _category = 4;
                    });
                  },
                  child: Text("/")
              )
            ],
          ),
          SizedBox(height: 80,),
          Row(
            children: [
              ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize: Size(320, 80)),
                  onPressed: () {
                    setState(() {
                      _firstNum = 0;
                      _category = 0;
                      _secondNum = 0;
                    });
                  },
                  child: Text("reset")
              ),
            ],
          ),
        ],
      ),
    );
  }
}
